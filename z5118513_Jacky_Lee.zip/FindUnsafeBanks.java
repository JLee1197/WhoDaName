/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentbprogramming;

import java.util.Scanner;

/**
 *
 * @author leeja_000
 */
public class FindUnsafeBanks {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Read the number of banks
        int n = input.nextInt();
        double[] balances = new double[n]; // Balance for each bank
        double[][] loan = new double[n][n]; // loan[i][j] is the amount bank i loans to bank j
        double limit = input.nextInt();
        int numberOfBorrowers = 0; //Number of banks borrowing
        int borrowingBank = 0; //The borrowing bank
        double amountBorrowed = 0;//The amount of money borrowed

        //Reads bank and the amount of borrowers that will borrow money from bank
        for (int i = 0; i < n; i++) {
            balances[i] = input.nextDouble();
            numberOfBorrowers = input.nextInt();
            //Reads the borrowing bank number and the amount of money that was borrowed.
            for (int q = 0; q < numberOfBorrowers; q++) {
                borrowingBank = input.nextInt();
                loan[i][borrowingBank] = input.nextDouble();
            }
        }

        //Count all the loans that bank[b] has given out and adds that loan to the total assets/balance of bank[b]
        for (int b = 0; b < n; b++) {
            for (int o = 0; o < n; o++) {
                balances[b] = balances[b] + loan[b][o];
            }
        }

        //Reads if bank[m] is under the limit then minus all the money that bank[m] has borrowed from other banks total balance. 
        for (int m = 0; m < n; m++) {
            if (balances[m] < limit) {
                for (int w = 0; w < n; w++) {
                    balances[w] = balances[w] - loan[w][m];
                }
            }
        }

        //If the banks balance is below the limit then it'll show that bank number as a unsafe bank
        System.out.print("Unsafe banks are ");
        for (int p = n - 1; p >= 0; p--) {
            if (balances[p] < limit) {
                System.out.print(p + " ");
            }
        }
    }

}
