/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentbprogramming;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author leeja_000
 */
public class ATM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Account account = new Account();//creates constructor
        account.Account();//no arg constructor to create single balance 
        account.accountArray();//no arg constructor to create an array[10]
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        account.dateCreated(date);//create date of when account was made/accessed
        int id;//variable to hold ID number
        int enteredNumber = 0;//variable to hold the number that was inputed within the menu
        double transactionMoney = 0;//the amount of money within the transaction of either withdrawing or depositing
        boolean atmOperating = true;//while loop to keep the atm operating at all times, until this boolean is set to false

        while (atmOperating == true) {
            System.out.print("Enter an ID: ");//enter ID number
            id = input.nextInt();
            if (id < 10) {//if statement to make sure ID number stays below 10
                account.chooseAccount(id);//logs in to account with that specific ID number
                enteredNumber = 0;
                //menu for user to input commands into the ATM
                while (enteredNumber != 4) {
                    System.out.println("Main Menu");
                    System.out.println("1: check balance");
                    System.out.println("2: withdraw");
                    System.out.println("3: deposit");
                    System.out.println("4: exit");
                    enteredNumber = input.nextInt();

                    if (enteredNumber == 4) {//if user presses 4, it'll break out of while loop and return to ID number request screen
                        break;
                    }

                    if (enteredNumber == 1) {//shows balance of that specific ID customer
                        account.showBalance();
                    }

                    if (enteredNumber == 2) {//asks user to input how much they wish to withdraw
                        System.out.println("Enter an amount to withdraw: ");
                        transactionMoney = input.nextDouble();
                        account.withdraw(transactionMoney);
                        transactionMoney = 0;
                    }

                    if (enteredNumber == 3) {//asks user to input how much they wish to deposit
                        System.out.println("Enter an amount to deposit: ");
                        transactionMoney = input.nextDouble();
                        account.deposit(transactionMoney);
                    }
                    if (enteredNumber > 4) {//error occurs and asks user to input another number
                        System.out.println("Please enter a number between 1 and 4.");
                    }
                }
            } else {//asks user to input a valid ID number 
                System.out.println("Please enter a valid ID number");
            }
        }
    }

}
