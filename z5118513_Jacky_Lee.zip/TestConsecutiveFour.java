/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentbprogramming;

/**
 *
 * @author leeja_000
 */
public class TestConsecutiveFour {

    public static void main(String[] args) {
        /*  You may use the following (6x7) array to test your program (e.g., false)
        0 1 0 6 1 6 1
        0 1 6 8 6 0 1
        5 2 2 1 8 2 9
        6 5 6 1 1 2 1
        6 9 6 2 1 9 1
        3 5 9 1 3 1 1
         */

 /*  The 1st sample (6x7 array) provide in the question is provided below (e.g., true)
        0 1 0 3 1 6 1
        0 1 6 8 6 0 1
        5 6 2 1 8 2 9
        6 5 6 1 1 9 1
        1 3 6 1 4 0 7
        3 3 3 3 4 0 7
         */
        java.util.Scanner input = new java.util.Scanner(System.in);
        System.out.print("Enter the number of rows: ");
        int numberOfRows = input.nextInt();//Inputs the number of rows in the array
        System.out.print("Enter the number of columns: ");
        int numberOfColumns = input.nextInt();//Inputs the number of columns in the array
        int[][] board = new int[numberOfRows][numberOfColumns];//Creates the array with the previous inputs

        System.out.println("Enter the array values: "); //Enters all the values into the array
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] = input.nextInt();
            }
        }
        System.out.println(isConsecutiveFour(board));//Returns a boolean value on whether or not there is four consecutive numbers in a line
    }

    //Method that checks for any four consecutive numbers in a straight line or diagonally in the array/inputted numbers.
    public static boolean isConsecutiveFour(int[][] values) {

        int numberOfRows = values.length;
        int numberOfColumns = values[0].length;
        boolean isEqual = true; //set boolean value to default true
        int columnNumber = 0; //variable that is the starting column for each directional check 
        int rCopy = 0;//an extra copy of the row number as a variable

        //for loop that goes through each row, one line at a time and checking each direction from each point within that row where 4 consecutive numbers fit
        for (int r = 0; r < numberOfRows; r++) {

            //Checks the rows for consecutive numbers in a line horizontally and returns a either returns a true value or values stays false
            if (values[0].length > 4) {
                for (int i = 0; i < numberOfColumns - 3; i++) {

                    for (int q = i; q < i + 3; q++) {
                        if (values[r][q] != values[r][q + 1]) {
                            isEqual = false;
                            break;
                        } else {
                            isEqual = true;
                        }

                    }
                    if (isEqual == true) {
                        break;
                    }
                }
                if (isEqual == true) {
                    return true;
                }
            }

            // Checks the columns for consecutive numbers in a line vertically and returns a either returns a true value or values stays false
            if (values.length > 4) {
                for (int w = 0; w < numberOfColumns - 3; w++) {

                    for (int e = w; e < w + 3; e++) {
                        if (values[e][r] != values[e + 1][r]) {
                            isEqual = false;
                            break;
                        } else {
                            isEqual = true;
                        }
                    }
                    if (isEqual == true) {
                        break;
                    }
                }
                if (isEqual == true) {
                    return true;
                }

            }

            // Checks the array for consecutive numbers in a line diagonally (south-east direction) and returns a either returns a true value or values stays false
            if (values.length >= 4 && values[0].length >= 4 && r < numberOfRows - 3) {
                columnNumber = 0;
                for (int m = columnNumber; m < numberOfColumns - 3; m++) {
                    rCopy = r;
                    for (int s = m; s < m + 3; s++) {
                        if (values[rCopy][s] != values[rCopy + 1][s + 1]) {
                            isEqual = false;
                            break;
                        } else {
                            isEqual = true;
                            rCopy++;
                        }

                    }
                    if (isEqual == true) {
                        break;
                    }
                }
                if (isEqual == true) {
                    return true;
                }

            }

            // Checks the array for consecutive numbers in a line diagonally (north-east direction) and returns a either returns a true value or values stays false
            if (values.length > 4 && values[0].length > 4 && r > 2) {
                columnNumber = 0;
                for (int l = columnNumber; l < numberOfColumns - 3; l++) {
                    rCopy = r;
                    for (int x = l; x < l + 3; x++) {

                        if (values[rCopy][x] != values[rCopy - 1][x + 1]) {
                            isEqual = false;
                            break;
                        } else {
                            isEqual = true;
                            rCopy--;
                        }

                    }
                    if (isEqual == true) {
                        break;
                    }
                }
                if (isEqual == true) {
                    return true;
                }

            }

            //Checks the array for consecutive numbers in a line diagonally (south-west direction) and returns a either returns a true value or values stays false
            if (values.length > 4 && values[0].length > 4 && r < numberOfRows - 3) {
                columnNumber = numberOfColumns - 1;
                for (int g = columnNumber; g > 2; g--) {
                    rCopy = r;
                    for (int f = g; f > g - 3; f--) {

                        if (values[rCopy][f] != values[rCopy + 1][f - 1]) {
                            isEqual = false;
                            break;
                        } else {
                            isEqual = true;
                            rCopy++;
                        }

                    }
                    if (isEqual == true) {
                        break;
                    }
                }
                if (isEqual == true) {
                    return true;
                }

            }

            //Checks the array for consecutive numbers in a line diagonally (north-west direction)
            if (values.length > 4 && values[0].length > 4 && r > 2) {
                columnNumber = numberOfColumns - 1;
                for (int u = columnNumber; u > 2; u--) {
                    rCopy = r;
                    for (int y = u; y > u - 3; y--) {

                        if (values[rCopy][y] != values[rCopy - 1][y - 1]) {
                            isEqual = false;
                            break;
                        } else {
                            isEqual = true;
                            rCopy--;
                        }

                    }
                    if (isEqual == true) {
                        break;
                    }
                }
                if (isEqual == true) {
                    return true;

                }
            }
        }

        return false;
    }

    //checks when a single row was inputted, if there are four consecutive numbers within that single row and returns a value
    public static boolean isConsecutiveFour(int[] values) {
        for (int i = 0; i < values.length - 3; i++) {
            boolean isEqual = true;
            for (int j = i; j < i + 3; j++) {
                if (values[j] != values[j + 1]) {
                    isEqual = false;
                    break;
                }
            }

            if (isEqual) {
                return true;
            }
        }

        return false;
    }

}
