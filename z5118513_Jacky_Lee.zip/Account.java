/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentbprogramming;

import java.util.Date;

/**
 *
 * @author leeja_000
 */
public class Account {

    private int id; //id variable
    private double balance;//balance variable
    private static double annualInterestRate;//annual interest rate variable
    private java.util.Date dateCreated;// date the account was created variable
    private double[] accountBalance = new double[10];// array of 10 for total balances within the system

    public void Account() {

    }

    public void accountArray() {//fills the array with values (default 100 per account)
        for (int i = 0; i < 10; i++) {
            accountBalance[i] = 100.00;
        }
    }

    public void annualInterestRate(double rate) {//inputs the annual interest rate
        annualInterestRate = rate;
    }

    public void changeBalance(double money) {//allows the balance of a specific account to change
        balance = money;
        accountBalance[id] = money;
    }

    public void chooseAccount(int id) {// sets the account ID 
        this.id = id;
    }

    public void showBalance() {//shows the balance for that account ID
        System.out.println("The balance is: " + accountBalance[id]);
    }

    public void withdraw(double money) {//withdraws money, and if there isn't enough money an error message will occur
        if (money <= accountBalance[id]) {
            accountBalance[id] = accountBalance[id] - money;
        } else {
            System.out.println("You do not current have enough funds to withdraw $" + money);
        }
    }

    public void deposit(double money) {//deposit money into the account 
        accountBalance[id] = accountBalance[id] + money;
    }

    public void dateCreated(Date date) {//sets the date variable
        dateCreated = date;

    }

    public void getDateCreated() {//retrieves the date variable
        System.out.println(dateCreated);
    }

    public double getMonthlyInterestRate() {//finds the monthly interest rate
        return annualInterestRate / 12;
    }

    public double getMonthlyInterest() {//finds the monthly interest based on the monthly interest rate
        return accountBalance[id] * (annualInterestRate / 12);
    }

    public double getAnnualInterestRate() {//retrieves the annual interest rate
        return annualInterestRate;

    }

    public int getID() {//retrieves the id of the account
        return id;
    }

    public double getBalance() {//retrieves the single balance
        return balance;
    }
}
