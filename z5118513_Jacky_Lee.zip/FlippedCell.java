/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignmentbprogramming;

import java.util.Scanner;

/**
 * The following 6x6 matrix contains a flipped cell at (0,1) 
 * 1 1 1 0 1 1 
 * 1 1 1 1 0 0
 * 0 1 0 1 1 1
 * 1 1 1 1 1 1
 * 0 1 1 1 1 0
 * 1 0 0 0 0 1
 *
 * The following 6x6 matrix has no flipped cell 
 * 1 0 1 0 1 1 
 * 1 1 1 1 0 0
 * 0 1 0 1 1 1
 * 1 1 1 1 1 1
 * 0 1 1 1 1 0
 * 1 0 0 0 0 1
 */
// Complete the class below
public class FlippedCell {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int totalOnes = 0; //variable that keeps track of how many 1's have occured within the row/column
        int violatedRow = -1; //if this variable doesn't equal -1 then it will record the number where the violated cell is within the row
        int violatedColumn = -1;//if this variable doesn't equal -1 then it will record the number where the violated cell is within the column
        System.out.print("Enter a 6-by-6 matrix row by row: ");
        int[][] board = new int[6][6]; //generates a 6-by-6 array
        //inputs values into the array
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] = input.nextInt();
            }
        }
        //for loop that checks each row, counts amount of ones and if it's odd it'll record the violated row number
        for (int k = 0; k < board.length; k++) {
            totalOnes = 0;
            for (int l = 0; l < board[0].length; l++) {
                if (board[k][l] == 1) {
                    totalOnes++;
                }

            }
            if (totalOnes % 2 != 0) {
                violatedRow = k;
                break;
            }
            //for loop that checks each column, counts the amount of ones and if it's off it'll record the violated column number
        }
        for (int m = 0; m < board[0].length; m++) {
            totalOnes = 0;
            for (int n = 0; n < board.length; n++) {
                if (board[n][m] == 1) {
                    totalOnes++;
                }

            }
            if (totalOnes % 2 != 0) {
                violatedColumn = m;
                break;
            }
            //checks if violated row and column has been recorded(leads to it not being -1) and prints out the violated row and column
        }
        if (violatedRow != -1 && violatedColumn != -1) {
            System.out.println("The flipped cell is " + violatedRow + ", " + violatedColumn);
        } else {
            System.out.println("There is no flipped cell."); // if no column then prints out there aren't any flipped cells
        }
    }

}
