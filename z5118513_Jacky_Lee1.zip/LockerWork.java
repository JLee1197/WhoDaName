/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignmenta;

import java.util.Arrays;

/**
 *
 * @author leeja_000
 */
public class LockerWork {

    /**
     * Program to find which lockers are opened after all the students open/close them in different orders
     */
    public static void main(String[] args) {
        int studentNumber = 0;
        int studentLockers = 0;
        int lockerNumber = 0;
        int incrementIncrease = 1;
        //array for lockers which are all closed/false
        boolean[] lockers = new boolean[100];
        int numberOfLockers = 100;
        //loops to open and close lockers depending on person
        for (int i = 0; i < lockers.length; i++) {
            studentLockers = 0;
            for (int q = 0; q <= 100; q++) {
                if (lockerNumber + (studentLockers) < 100) {
                    if (lockers[(lockerNumber + studentLockers)] == false) {
                        lockers[(lockerNumber + studentLockers)] = true;
                    } else if (lockers[(lockerNumber + studentLockers)] == true) {
                        lockers[(lockerNumber + studentLockers)] = false;
                    } else {
                        break;
                    }
                }
                studentLockers = studentLockers + incrementIncrease;
            }
            lockerNumber++;
            incrementIncrease++;
            
//displays the opened lockers
        }
        for (int i = 0; i < numberOfLockers; i++) {

            if (lockers[i] == true) {
                System.out.println("Locker " + (i + 1) + " is open");
            }
        }
    }
}
