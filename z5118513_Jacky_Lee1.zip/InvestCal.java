/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignmenta;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author leeja_000
 */
public class InvestCal {
//Question 3 of Assignment A

    /**
     * Program that computes future investment value
     */
    public static void main(String[] args) {
        DecimalFormat f = new DecimalFormat("##.00");
        Scanner input = new Scanner(System.in);
        double futureInvestmentValue = 0;
        System.out.print("The amount invested: ");
        double investmentAmount = input.nextDouble();
        System.out.println("Annual interest rate: ");
        double annualInterestRate = input.nextDouble();
        double monthlyInterestRate = (double) (annualInterestRate / 100) / 12;
        int years = 1;
        System.out.println("Years             Future Value   ");
        futureInvestmentValue(investmentAmount, monthlyInterestRate, years);

    }
//method that calculates the future investment value
    public static double futureInvestmentValue(double investmentAmount, double monthlyInterestRate, int years) {
DecimalFormat f = new DecimalFormat("##.00");
double result = 0;
        while (years <= 30) {
            
            result = investmentAmount * Math.pow(1 + monthlyInterestRate, years * 12);

            System.out.println(years + "                   " + f.format(result));
            years++;

            
        }
        return result;
    }
}
