/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignmenta;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author leeja_000
 */
public class TaxCal {
//Question 1 Assignment A
    /**
     * Calculating personal income tax based on filing status and taxable income
     */
    public static void main(String[] args) {
        DecimalFormat f = new DecimalFormat("##.00");
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the filing status: ");
        int filingStatus = input.nextInt();
        System.out.println("Enter the taxable income: ");

        double principleIncome = input.nextDouble();
        double taxableIncome = principleIncome;
        double taxRate = 0.00;
        double tenPercentTax = 0.00;
        double fifteenPercentTax = 0.00;
        double twentyfivePercentTax = 0.00;
        double twentyeightPercentTax = 0.00;
        double thirtythreePercentTax = 0.00;
        double thirtyfivePercentTax = 0.00;
//when filing status is 0
        if (filingStatus == 0) {
            if (taxableIncome - 8350 > 0) {
                tenPercentTax = 8350 * 0.1;
                taxableIncome = taxableIncome - 8350;
            } else {
                tenPercentTax = taxableIncome * 0.1;
                taxableIncome = 0;
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 25600 > 0) {
                    fifteenPercentTax = 25600 * 0.15;
                    taxableIncome = taxableIncome - 25600;
                } else {
                    fifteenPercentTax = taxableIncome * 0.15;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 48300 > 0) {
                    twentyfivePercentTax = 48300 * 0.25;
                    taxableIncome = taxableIncome - 48300;
                } else {
                    twentyfivePercentTax = taxableIncome * 0.25;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 89300 > 0) {
                    twentyeightPercentTax = 89300 * 0.28;
                    taxableIncome = taxableIncome - 89300;
                } else {
                    twentyeightPercentTax = taxableIncome * 0.28;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 201400 > 0) {
                    thirtythreePercentTax = 201400 * 0.33;
                    taxableIncome = taxableIncome - 201400;
                } else {
                    thirtythreePercentTax = taxableIncome * 0.33;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                thirtyfivePercentTax = taxableIncome * 0.35;
            }
        }
//When Filing Status is 1

        if (filingStatus == 1) {
            if (taxableIncome - 16700 > 0) {
                tenPercentTax = 16700 * 0.1;
                taxableIncome = taxableIncome - 16700;
            } else {
                tenPercentTax = taxableIncome * 0.1;
                taxableIncome = 0;
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 51200 > 0) {
                    fifteenPercentTax = 51200 * 0.15;
                    taxableIncome = taxableIncome - 51200;
                } else {
                    fifteenPercentTax = taxableIncome * 0.15;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 69150 > 0) {
                    twentyfivePercentTax = 69150 * 0.25;
                    taxableIncome = taxableIncome - 69150;
                } else {
                    twentyfivePercentTax = taxableIncome * 0.25;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 71800 > 0) {
                    twentyeightPercentTax = 71800 * 0.28;
                    taxableIncome = taxableIncome - 71800;
                } else {
                    twentyeightPercentTax = taxableIncome * 0.28;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 164100 > 0) {
                    thirtythreePercentTax = 164100 * 0.33;
                    taxableIncome = taxableIncome - 164100;
                } else {
                    thirtythreePercentTax = taxableIncome * 0.33;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                thirtyfivePercentTax = taxableIncome * 0.35;
            }
        }
        //When filing status is 2
        if (filingStatus == 2) {
            if (taxableIncome - 8350 > 0) {
                tenPercentTax = 8350 * 0.1;
                taxableIncome = taxableIncome - 8350;
            } else {
                tenPercentTax = taxableIncome * 0.1;
                taxableIncome = 0;
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 25600 > 0) {
                    fifteenPercentTax = 25600 * 0.15;
                    taxableIncome = taxableIncome - 25600;
                } else {
                    fifteenPercentTax = taxableIncome * 0.15;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 34575 > 0) {
                    twentyfivePercentTax = 34575 * 0.25;
                    taxableIncome = taxableIncome - 34575;
                } else {
                    twentyfivePercentTax = taxableIncome * 0.25;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 35900 > 0) {
                    twentyeightPercentTax = 35900 * 0.28;
                    taxableIncome = taxableIncome - 35900;
                } else {
                    twentyeightPercentTax = taxableIncome * 0.28;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 82050 > 0) {
                    thirtythreePercentTax = 82050 * 0.33;
                    taxableIncome = taxableIncome - 82050;
                } else {
                    thirtythreePercentTax = taxableIncome * 0.33;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                thirtyfivePercentTax = taxableIncome * 0.35;
            }
        }
        //when filing status is 3
        if (filingStatus == 3) {
            if (taxableIncome - 11950 > 0) {
                tenPercentTax = 11950 * 0.1;
                taxableIncome = taxableIncome - 11950;
            } else {
                tenPercentTax = taxableIncome * 0.1;
                taxableIncome = 0;
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 33550 > 0) {
                    fifteenPercentTax = 33550 * 0.15;
                    taxableIncome = taxableIncome - 33550;
                } else {
                    fifteenPercentTax = taxableIncome * 0.15;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 71950 > 0) {
                    twentyfivePercentTax = 71950 * 0.25;
                    taxableIncome = taxableIncome - 71950;
                } else {
                    twentyfivePercentTax = taxableIncome * 0.25;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 72750 > 0) {
                    twentyeightPercentTax = 72750 * 0.28;
                    taxableIncome = taxableIncome - 72750;
                } else {
                    twentyeightPercentTax = taxableIncome * 0.28;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                if (taxableIncome - 152750 > 0) {
                    thirtythreePercentTax = 152750 * 0.33;
                    taxableIncome = taxableIncome - 152750;
                } else {
                    thirtythreePercentTax = taxableIncome * 0.33;
                    taxableIncome = 0;
                }
            }

            if (taxableIncome > 0) {
                thirtyfivePercentTax = taxableIncome * 0.35;
            }
        }
        System.out.println(
                "Tax is " + f.format((tenPercentTax + fifteenPercentTax + twentyfivePercentTax
                        + twentyeightPercentTax + thirtythreePercentTax + thirtyfivePercentTax)));

    }
}
