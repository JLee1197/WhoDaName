/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignmenta;

/**
 *
 * @author leeja_000
 */
public class FindMax {
//Question 2 of Assignment A
    /**
     * Program that reads integers, finds max and counts occurrences of max
     */
    public static void main(String[] args) {

        java.util.Scanner input = new java.util.Scanner(System.in);
        // Prompt the user to enter the first number
        System.out.print("Enter numbers: ");
        int number = input.nextInt();
        int max = number;
        int count = 1;

        while (number != 0) {
            number = input.nextInt(); // Read the next number
            if (number == 0) {
                break;
            }
            if (number > max) {
                max = number;
                count = 1;
            } else if (number == max) {
                count++;
            } else if (number < max) {
                continue;
            }
        }

        System.out.println("The largest number is " + max + "\n"
                + "The occurrence count of the largest number is " + count);
    }
}
